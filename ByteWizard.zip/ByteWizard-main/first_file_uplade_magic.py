#!/usr/bin/env python3

def line_prepender(filename, line):
    with open(filename, 'r+') as f:
        
        content = f.read()
        f.seek(0, 0)
        #f.write(line + content)
        f.write(line.rstrip('\r\n') + '\n' + content)

def file_headr(filename, filetype):
    with open(filename, 'rb+') as f:
        
        f.seek(0, 0)
        f.write(filetype)
        f.close()



#user input to chose the file type png , pdf ......
print("1:pdf\n2:mb3'audio'\n3:jpg\n4:pcapng\n5:GIF")

user_input = int(input("chose the number :"))
if user_input == 1:
    file_type = b'\x25\x50\x44\x46\x2D'
    file_newline = "AAAAA\n"
elif user_input == 2:
    file_type = b'\x49\x44\x33'
    file_newline = "AAA\n"
elif user_input == 3:
    file_type = b'\xFF\xD8\xFF\xE0'
    file_newline = "AAAA\n"
elif user_input == 4:
    file_type = b'\xD4\xC3\xB2\xA1'
    file_newline = "AAAA\n"
elif user_input == 5:
    file_type = b'\x47\x49\x46\x38\x39\x61'
    file_newline = "AAAAAA\n"
else: 
    print("error")

#file_type = b'\xFF\xD8\xFF\xE0' #switc 
#file_newline = "AAAAAAAA\n"
file_name = input("Enter file name : ")
line_prepender(file_name, file_newline)
file_headr(file_name,file_type)
#FF D8 FF E0