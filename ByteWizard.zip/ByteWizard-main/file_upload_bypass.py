#!/usr/bin/env python3

def line_prepender(filename, line):
    with open(filename, 'r+') as f:
        content = f.read()
        f.seek(0, 0)
        f.write(line.rstrip('\r\n') + '\n' + content)



file_type = "%PDF-"

file_name = input("Enter file name : ")
line_prepender(file_name, file_type)
