# Byte Wizard 🧙
![image](https://user-images.githubusercontent.com/58490288/193213111-041e3304-33e7-4a3e-8997-4c9660d4a52b.png)

Our goal is to make a tool that changes the files signatures AKA (Magic Bytes) to help pentesters in bypassing file upload security functions.

## Authors:
- Ahmad Bahkali [@unknownamd_](https://twitter.com/unknownamd_)
- Mohammed Aljayzani [@z5jt4](https://twitter.com/z5jt4)
- Yousef Alfuhaid [@Pho1yalfuhaid](https://twitter.com/Pho1yalfuhaid)

## installing the tool:
```
git clone https://github.com/z5jt/ByteWizard.git
cd ByteWizard
pip3 install -r requirements.txt
python3 ByteWizard.py
```
## v1.0:

### Note (Next Step):
- Metadata changer 



### v1.2:
Soon..

- PHP shell code injection in files. 

للمجد قادمون

#### Disclaimer
Usage of ~sqlmap~ **Byte Wizard** for attacking targets without prior mutual consent is illegal. It is the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program.
