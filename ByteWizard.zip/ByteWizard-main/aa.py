#!/usr/bin/env python3
from art import *

print(""" 
                                      .

                                       .
                             /^\     .
                        /\   "V"
                       /__\   I      O  o
                      //..\\  I     .
                      \].`[/  I
                      /l\/j\  (]    .  O
                     /. ~~ ,\/I          .
                     \\L__j^\/I       o
                      \/--v}  I     o   .
                      |    |  I   _________
                      |    |  I c(`       ')o
                      |    l  I   \.     ,/
                    _/j  L l\_!  _//^---^\\_  
                                                                                          
         ------------------- Twitter -------------------
          ----- @z5jt4 @unknownamd_ @Pho1yalfuhaid -----        """) 
 
banner = text2art("Byte Wizard")
print(banner)
 
 
def line_prepender(filename, line):
    with open(filename, 'r+') as f:
        
        content = f.read()
        f.seek(0, 0)
        #f.write(line + content)
        f.write(line.rstrip('\r\n') + '\n' + content)

def file_header(filename, filetype):
    with open(filename, 'rb+') as f:
        
        f.seek(0, 0)
        f.write(filetype)
        f.close()



#user input to chose the file type png , pdf ......
print("""Select the filetype that you want to convert to:
          1- PDF
          2- MP3 (audio)
          3- jpg
          4- pcapng
          5- GIF""")
try:          
  user_input = int(input("chose the number :"))
except ValueError:
 print("Only Numbers are Accepted")
 user_input = int(input("chose the number :"))
if user_input <= 5:
 if user_input == 1:
    file_type = b'\x25\x50\x44\x46\x2D'
    file_newline = "AAAAA\n"
 elif user_input == 2:
    file_type = b'\x49\x44\x33'
    file_newline = "AAA\n"
 elif user_input == 3:
    file_type = b'\xFF\xD8\xFF\xE0'
    file_newline = "AAAA\n"
 elif user_input == 4:
    file_type = b'\xD4\xC3\xB2\xA1'
    file_newline = "AAAA\n"
 elif user_input == 5:
    file_type = b'\x47\x49\x46\x38\x39\x61'
    file_newline = "AAAAAA\n"
 

#ADD METADATA


 #file_type = b'\xFF\xD8\xFF\xE0' #switch
 #file_newline = "AAAAAAAA\n"
 file_name = input("Enter file name : ")


 try: 
     while(True):
      line_prepender(file_name, file_newline)
      file_header(file_name,file_type)
      break  
 except FileNotFoundError:
  print("ERROR 404: File not found, ")
  print(file_name)

   
 #FF D8 FF E0
else:
 print("ERROR: Choose a filetype from the list :\)")
 exit()
 
print("""Your file %s type have been changed succsessfully by Byte Wizard
Bye ;\)""")

